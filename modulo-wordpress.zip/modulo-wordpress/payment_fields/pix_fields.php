<form action="your_processing_script.php" method="post">
    <fieldset>
        <div class="form-row form-row-wide">                    
            <input type="text" name="session_id" id="session_id">
            <input type="text" name="session_id2" id="session_id2">
           <input type="button" name="add_session_id" value="Add Session ID" onclick="addSesionId()">
        </div>  
    </fieldset>
</form>

<?php 

    $fingerprint = isset($fingerprint) ? $fingerprint : '';

    echo <<<HTML
    <script>
    window.onload = (function(){         
        console.log("valor finger dentro do template", "{$fingerprint}");        
        AQPAGOSECTION.setPublicToken("{$fingerprint}");   
        });

        function addSesionId() {
            var a = AQPAGOSECTION.getSessionID();
            document.getElementById('session_id').value = a;
            if (!document.cookie.includes('session_id').value != null) {
                document.cookie = "session_id=" + a + "; path=/";
            }
        }

        function handlerPix(event) {
            alert('oi')                   
        } 

        function checkAqPagoSection() {
            var checkInterval = setInterval(function() {
                if (AQPAGOSECTION) {
                    
                
                    if (!document.cookie.includes('session_id') && !document.cookie.includes('session_id').value != null) {
                        var a = AQPAGOSECTION.getSessionID();
                        document.getElementById('session_id').value = a;
                        document.cookie = "session_id=" + a + "; path=/";
                        clearInterval(checkInterval);
                    }

                    else{

                        //se tem no sesion id no cookie seta no input o valor que ta no cookie
                        var cookieValue = document.cookie
                        .split('; ')
                        .find(row => row.startsWith('session_id'))
                        .split('=')[1];
                        document.getElementById('session_id').value = cookieValue;
                        clearInterval(checkInterval);
                    }
           
                }
            }, 1000);
        }

        checkAqPagoSection();

   
    </script>
    HTML;       

?>