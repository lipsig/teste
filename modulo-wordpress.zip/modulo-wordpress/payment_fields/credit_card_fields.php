<?php $order_id = $GLOBALS['order_id']; ?>

<form action="your_processing_script.php" method="post">
    <fieldset>
        <div class="form-row form-row-wide">                    
            <input type="text" maxlength="16" placeholder="Número do cartão" name="credit_card_number" id="credit_card">
            <input type="text" maxlength="5" placeholder="Data de expiração formato MM/AA" name="credit_card_expiration_date" id="credit_card_expiration_date">
            <input type="text"  maxlength="3" placeholder="Código 3 dígitos" name="credit_card_code" id="credit_card_code" >
            <input type="text" placeholder="Nome do Titular no Cartão" name="credit_card_name" id="credit_card_name">
            <input type="text" placeholder="CPF do Titular" name="credit_card_cpf" id="credit_card_cpf">
            <input type="hidden"  name="cc_number" id="cc_number">
            <input type="hidden" name="cc_validation_date" id="cc_validation_date">
            <input type="hidden" name="cc_code">
            <input type="hidden" name="cc_name">
            <input type="hidden" name="cc_cpf">
        </div>
        <input type="submit" value="Submit">
    </fieldset>
</form>

<script type="text/javascript">    
    function ccHandler() {
        $("#credit_card").on('input', function() {
            $("#cc_number").val($(this).val());
        });
    }
    function ccExpirationHandler() {
        $("#credit_card_expiration_date").on('input', function() {
            var expiration = $(this).val();
            var expirationArray = expiration.split('/');
            $("#cc_validation_month").val(expirationArray[0]);
            $("#cc_validation_year").val(expirationArray[1]);
        });
    }          
    $(document).ready(function() {
        ccHandler();
        ccExpirationHandler();
    });
</script>