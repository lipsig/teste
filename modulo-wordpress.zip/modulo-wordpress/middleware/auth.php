<?php


class Authenticate {    
    
    private $token;
    private $fingerprint;

    public function __construct(
        private $tax_document,
        private $secret_access_key,
        private $api_url
    ){
    }
    public function getTaxDocument() {
        return $this->tax_document;
    }
    public function setTaxDocument($tax_document) {
        $this->tax_document = $tax_document;
        return $this;
    }
    public function getSecretAccessKey() {
        return $this->secret_access_key;
    }
    public function setSecretAccessKey($secret_access_key) {
        $this->secret_access_key = $secret_access_key;
        return $this;
    }        
    public function getApiUrl() {
        return $this->api_url;
    }
    public function setApiUrl($api_url) {
        $this->api_url = $api_url;
        return $this;
    }
    public function getToken() {
        return $this->token;
    }
    public function setToken($token){
        $this -> token = $token;
        return $this;
    }
    public function getFingerprint() {
        return $this->fingerprint;
    }
    public function setFingerprint($fingerprint){
        $this -> fingerprint = $fingerprint;
        return $this;
    }
    public function authentication() {

        echo 'entrou aqui';

        $data = array(
            'tax_document' => $this->tax_document,
            'secret_access_key' => $this->secret_access_key
        );
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-Type: application/json',
                'content' => json_encode($data)
            )
        );
        
        $context = stream_context_create($options); 
        $result = file_get_contents($this->api_url, false, $context);

        error_log(print_r($http_response_header, true));

        echo 'result: ' . $result . ' -';   

        if ($result === FALSE) {
            error_log(print_r(error_get_last(), true));
            $errorMessage = 'Erro ao autenticar. ';
            $errorMessage .= 'TaxDocument atual: ' . $this->tax_document . ', ';
            $errorMessage .= 'Secret Access Key atual: ' . $this->secret_access_key;
            return $errorMessage;
        }

        $resultArray = json_decode($result, true);
        $this->setToken($resultArray['token']);
        $this->setFingerprint($resultArray['fingerprint']);

        return $resultArray;
    }    
  
}