<?php
require 'vendor/autoload.php';

require_once 'admin_config/aqbank_admin_fields.php';
require_once 'middleware/auth.php';
require_once 'models/webhook.php';
require_once 'webhook_service/check_webhook_aqpago.php';

class Aqbank_Payment_Gateway extends WC_Payment_Gateway {

    private $fingerprint;
    private $publicToken;
    private $session;


    public function __construct() {
        $this->id = 'aqpago'; 
        $this->icon = ''; 
        $this->has_fields = true; 
        $this->method_title = 'AqBank Gateway';
        $this->method_description = 'Description aqpago payment gateway'; 
        $this->supports = array(
            'products'
        );    
        $this->form_fields = aqbank_init_admin_fields();    
        $this->title = $this->get_option( 'title' );
        $this->description = $this->get_option( 'description' );
        $this->enabled = $this->get_option( 'enabled' );
        $this->taxDocument = $this->get_option('taxDocument');
        $this->secretKey = $this->get_option('secretKey');
        $this->enable_for_methods  		= $this->get_option( 'enable_for_methods' );
        
        $this->init_form_fields();

        $this->init_settings();

        // This action hook updates the saved settings from the admin page
        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

        add_action('wp_ajax_check_order_status', 'check_order_status');
        add_action('wp_ajax_nopriv_check_order_status', 'check_order_status');    

		add_action( 'woocommerce_api_aqpago_webhook', array( $this, 'webhook' ) );


        // handler da pagina de sucesso
        add_action('woocommerce_thankyou_aqpago', array($this, 'aqpago_woocommerce_thankyou'), 1 );
		add_action('woocommerce_order_details_before_order_table', array($this, 'aqpago_order_details_before_order_table'), 10, 4 );

        
        //lib aqpago para resgatar o session id
        wp_enqueue_script('aqpago', 'http://127.0.0.1:8000/js/aqpago.min.js', array(), null, true);


        // // esse action hook é para carregar o script do aqpago na página de checkout
        // add_action( 'woocommerce_before_checkout_form', array($this,'authAqpago') );

        //se o tax document e o secret key estiverem setados, autentica o aqpago
        if(isset($this->taxDocument) && isset($this->secretKey)){
            $this->authAqpago();
        } else {
            wc_add_notice('Token não encontrado, 
            por favor verifique se os campos do admin foram setados,
             em dúvida entre em contato com o nosso suporte', 'error');
        }


    }

    public function authAqpago() {

        // usar o namespace App\Http\Webhook;


        if(isset($this->taxDocument) && isset($this->secretKey)){
        $auth = new Authenticate(
            $this->get_option('taxDocument'),
            $this->get_option('secretKey'),
            'http://127.0.0.1:8000/api/auth/login'
        );

        $token = $auth->authentication();

        if($token) {
            $this->setFingerprint($token['fingerprint']);
            $this->setPublicToken($token['token']);

            // Se a autenticação for bem-sucedida, crie o webhook
            $this->createWebhook();

            return true;

        } else {
            wc_add_notice('Token não encontrado, 
            por favor verifique se os campos do admin foram setados,
             em dúvida entre em contato com o nosso suporte', 'error');
            
             return false;
        }  
    }
    }
    
    public function createWebhook() {

        // da um echo no token
        echo 'token: ' . $this->getPublicToken();

        $baseUrl = get_site_url();

        $webhook = new Webhook();
        $webhook->setEvent([
            "transaction.success",
            "transaction.succeeded",
            "transaction.reversed",
            "transaction.failed",
            "transaction.canceled",
            "transaction.disputed",
            "transaction.charged_back",
            "transaction.pre_authorized"
        ]);
        $webhook->setUrl($baseUrl. '/wc-api/aqpago_webhook');
        $webhook->setDescription('modulo woocommerce');
        $webhook->setMethod('POST');
    

        $webhookCreator = new CheckWebhookAqPago('http://127.0.0.1:8000/api/webhook', $this->getPublicToken());
        $webhookCreator->ensureWebhookExists($webhook);
    }

    public function aqpago_order_details_before_order_table( $order ) {
        
		if (is_wc_endpoint_url('order-received')){   
			$this->aqpago_woocommerce_thankyou( $order->get_id() );
		}
	}

    	
	public function aqpago_woocommerce_thankyou($order_id) {
		$orderWoocommerce = new WC_Order($order_id);
		$payment_method   = get_post_meta($order_id, '_payment_method', true);
		
		if ($payment_method == 'aqpago') {
			$type       	  = get_post_meta($order_id, '_type_payment', true);
			$response   	  = get_post_meta($order_id, '_aqpago_response', true);
			$response   	  = json_decode($response, true);
			
			if (isset($response['payments'])) {
				$title = "";
				if ($type == 'ticket') {
					$title = __( 'Boleto', 'woocommerce' ); 
				} elseif ($type == 'credit') {
					$title = __( 'Cartão de Crédito', 'woocommerce' ); 
				} elseif ($type == 'credit_multiple') {
					$title = __( '2 Cartões', 'woocommerce' ); 
				} elseif ($type == 'ticket_multiple') {
					$title = __( 'Cartão + Boleto', 'woocommerce' ); 
				}
				
				$flagVisa = plugins_url('assets/images/visa.png', plugin_dir_path( __FILE__ ) );
				
				wc_get_template(
					'response.php', array(
						'id'				=> $order_id,
						'status' 			=> $this->trans_erros( $response['status'] ),
						'order'				=> $orderWoocommerce,
						'flagVisa'			=> $flagVisa,
						'context'			=> $this,
						'response'			=> $response,
					), 
					'woocommerce/aqpago/', 
					WC_Aqpago::get_templates_path() . '/success/'
				);
			}
		}
	}
	

    public function setFingerprint($fingerprint) {
        $this->fingerprint = $fingerprint;
    }
    public function getFingerprint() {
        return $this->fingerprint;
    }
    public function setPublicToken($publicToken) {
        $this->publicToken = $publicToken;
    }
    public function getPublicToken() {
        return $this->publicToken;
    }

    
    public function payment_fields() {              
        global $woocommerce;
        $order_id = $woocommerce->session->get('order_awaiting_payment');
        $order = wc_get_order( $order_id );           
      
        $fingerLocal = $this->getFingerprint();

        $templateArgs = [
            'fingerprint' => $fingerLocal
        ];

   
        $enabled_methods = $this->get_option('enable_for_methods', array());
    
        foreach ($enabled_methods as $method) {
            switch ($method) {
                case 'credit':
                    include 'payment_fields/credit_card_fields.php';
                    break;
                case 'credit_multiple':
                    // Include fields for multiple credit cards
                    break;
                case 'ticket_multiple':
                    // Include fields for card & ticket
                    break;
                case 'pix':
                    include 'payment_fields/pix_fields.php';
                    break;
                case 'ticket':
                    // Include fields for ticket
                    break;
            }
        }

    }  
    
    public function payment_load_aqpago_session() {}
    public function payment_scripts() {}
    public function validate_fields() {}

    public function process_payment($order_id) {
        
        global $woocommerce;
    
        $order = wc_get_order($order_id);

        echo 'order: ' . json_encode($order);
       
        $order->update_status('on-hold', 'Aguardando pagamento.');
    
        $this->createOrder($order);        

                
   /*      //passar o qr code por query string para a página de sucesso do pedido 
        $redirect_url = $this->get_return_url($order);
        $redirect_url .= '&?qrCode=' . urlencode($this->qrcodeQuery);

        return array(
        'result' => 'success',
        'redirect' => $redirect_url
        );    
 */

    }

    public function createOrder($order) {             

        $sessionIdCookie;                
        $pbToken = $this-> getPublicToken();

        if (isset($_COOKIE['session_id'])) {
            $sessionIdCookie = $_COOKIE['session_id'];
            echo print_r($sessionIdCookie, true);
        } else {
            echo print_r('sem cookie', false);
        }

        echo 'token: ' . json_encode($pbToken);     

        $orderData = [
            'type' => 'pix',
            'session_id' => $sessionIdCookie,
            'items' => [
                [
                    'qty' => 1,
                    'link' => 'http://example.com',
                    'name' => 'Odonto',
                    'image' => 'http://example.com',
                    'amount' => 1.00
                ]
            ],
            'amount' => 1.00,
            'customer' => [
                'name' => 'Felipe',
                'type' => 'F',
                'email' => 'luis.lourezi@aqbank.com.br',
                'phones' => [
                    [
                        'area' => '35',
                        'number' => '988722247'
                    ]
                ],
                'address' => [
                    'city' => 'Sao Paulo',
                    'state' => 'SP',
                    'number' => '14',
                    'street' => 'Rua Tabapua',
                    'district' => 'Itaim Bibi',
                    'postcode' => '04533902'
                ],
                'lastname' => 'Lourenzi',
                'tax_document' => '02581571004'
            ],
            'payments' => [
                [
                    'type' => 'pix',
                    'amount' => 1.00,
                    'credit_card' => [
                        'document' => 'null',
                        'card_number' => 'null',
                        'holder_name' => 'null',
                        'installments' => 1,
                        'security_code' => 'null',
                        'expiration_year' => 'null',
                        'expiration_month' => 'null'
                    ]
                ]
            ],
            'reference_id' => '2994b72d-1523-4e9d-97d0-075aa83b9506',
            'qtd_dependents' => 1
        ];

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'http://127.0.0.1:8000/api/order');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($orderData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: Bearer ' . $pbToken,
            'User-Agent: My User Agent'
        ]);

        echo 'order: ' . (json_encode($orderData));

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        echo $response;

        if (curl_errno($ch)) {
            $error = 'Curl error: ' . curl_error($ch);
            echo $error;
        } else if ($status >= 400) {
            $httpError = 'HTTP error: ' . $status;
            $responseBody = 'Response body: ' . $response;
            echo $httpError;
            echo $responseBody;
        }

        $responseObj = json_decode($response);        

        if($responseObj){
            echo 'API request successful: ' . addslashes(print_r($responseObj, true));
        } else {
            echo 'API request failed: ' . addslashes(print_r($responseObj, true));
        }
        
        curl_close($ch);
        print_r($response);

   

 
    }

  

    public function webhook() {
        $entityBody = file_get_contents('php://input');
        $data = json_decode($entityBody, true);
    
        if (isset($data['order_id'])) {
            $order_id = $data['order_id'];
            $status = $data['status']; // assuming the status is also sent in the webhook
    
            $orderWoocommerce = wc_get_order( $order_id );
    
            switch ($status) {
                case 'ORDER_PAID': 
                    $orderWoocommerce->update_status('processing');
                    $orderWoocommerce->add_order_note( __('Atualizado por notificação!', 'woothemes') );
                    $orderWoocommerce->add_order_note( __('Pagamento recebido.', 'woothemes') );
                break;
                // ... rest of your switch cases
            }
    
            update_post_meta($order_id, '_aqpago_response', json_encode($data, JSON_PRETTY_PRINT));
        } else {
            echo "No order_id found in the request body.";
        }
    
    }
}