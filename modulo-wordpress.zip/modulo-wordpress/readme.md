
## Em Desenvolvimento

Esse projeto consiste em um Gateway de pagamento para WooCommerce da Aqbank para ser usado no Checkout


## Instalação

Para adicionar ao WordPress é necessário instalar como um plugin custom e ativar.

## Tecnologias

PHP
jQuery
Funções nativas de WooCommerce