<?php

function aqbank_init_admin_fields(){                
    return array(
        'enabled' => array(
            'title'       => 'Habilitar / Desabilitar',
            'label'       => 'Habilitar AqBank Gateway',
            'type'        => 'checkbox',
            'description' => '',
            'default'     => 'no'
        ),
        'title' => array(
            'title'       => 'Pagar com Pix',
            'type'        => 'text',
            'description' => 'This controls the title which the user sees during checkout.',
            'default'     => 'AqBank Gateway',
            'desc_tip'    => true,
        ),
        'description' => array(
            'title'       => 'Description',
            'type'        => 'textarea',
            'description' => 'This controls the description which the user sees during checkout.',
            'default'     => 'Pay with AqBank Gateway',
        ),
        'taxDocument' => array(
            'title'       => 'Tax Document',
            'type'        => 'text',
            'description' => 'Cnpj ou CPF do cadastrado na AqBank',
            'default'     => '',
            'desc_tip'    => true,
        ),
        'secretKey' => array(
            'title'       => 'Secret Key',
            'type'        => 'text',
            'description' => 'Token de acesso',
            'default'     => '',
            'desc_tip'    => true,
        ),
        'enable_for_methods' => array(
            'title'             => __( 'Ativar métodos', 'woocommerce' ),
            'type'              => 'multiselect',
            'class'             => 'wc-enhanced-select',
            'css'               => 'width: 400px;',
            'default'           => array(0 => 'credit',1 => 'credit_multiple', 2 => 'ticket_multiple', 3 => 'pix', 4 => 'ticket'),
            'description'       => __( 'Meios de pagamento que aparecem para o cliente no checkout.', 'woocommerce' ),
            'options'           => array(
                'credit'  => __( 'Cartão de Crédito', 'woocommerce' ),
                'credit_multiple'  => __( '2 Cartão de Crédito', 'woocommerce' ),
                'ticket_multiple'  => __( 'Cartão & Boleto', 'woocommerce' ),
                'pix'  => __( 'PIX', 'woocommerce' ),
                'ticket'  => __( 'Boleto', 'woocommerce' ),
            ),
            'desc_tip'          => true,
            'custom_attributes' => array(
                'data-placeholder' => __( 'Selecione os métodos de pagamento', 'woocommerce' )
            )
        ),
        'installments' => array(
            'title' => __( 'Parcelar em até', 'woocommerce' ),
            'type' => 'select',
            'description' => __( 'Define quantas parcelas sua loja ofertará no checkout', 'woocommerce' ),
            'desc_tip' => true,
            'default' => '12',
            'class' => 'wc-enhanced-select',
            'options' => array(
                '1'  => __( '1x', 'woocommerce' ),
                '2'  => __( '2x', 'woocommerce' ),
                '3'  => __( '3x', 'woocommerce' ),
                '4'  => __( '4x', 'woocommerce' ),
                '5'  => __( '5x', 'woocommerce' ),
                '6'  => __( '6x', 'woocommerce' ),
                '7'  => __( '7x', 'woocommerce' ),
                '8'  => __( '8x', 'woocommerce' ),
                '9'  => __( '9x', 'woocommerce' ),
                '10' => __( '10x', 'woocommerce' ),
                '11' => __( '11x', 'woocommerce' ),
                '12' => __( '12x', 'woocommerce' )
            )
        ),
        'min_total_installments' => array(
            'title' => __( 'Valor mínimo para parcelamento', 'woocommerce' ),
            'type' => 'text',
            'description' => sprintf( __( 'Define um valor mínimo para cada parcela, deixar como 0 para qualquer valor.', 'woocommerce' )),
            'default' => '0',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
            'class' => 'aqpago-price',
        ),
        'installment_interest_free' => array(
            'title' => __( 'Parcelar com juros', 'woocommerce' ),
            'type' => 'select',
            'description' => __( 'Cobrança de juros para o cliente.', 'woocommerce' ),
            'desc_tip' => false,
            'default' => '0',
            'class' => 'wc-enhanced-select',
            'options' => array(
                '0'  => __( 'Não', 'woocommerce' ),
                '1'  => __( 'Sim', 'woocommerce' )
            )
        ),
        'installment_type' => array(
            'title' => __( 'Tipo de taxas', 'woocommerce' ),
            'type' => 'select',
            'description' => __( 'Ao utilizar Taxa AQPago será aplicado a taxa do seu plano para cada parcela.', 'woocommerce' ),
            'desc_tip' => false,
            'default' => 'aqpago',
            'class' => 'wc-enhanced-select',
            'options' => array(
                'aqpago'  => __( 'Taxas do meu plano AQPago', 'woocommerce' ),
                'custom'  => __( 'Taxas personalizadas', 'woocommerce' )
            )
        ),
        'installment_up_to' => array(
            'title' => __( 'Parcelar com juros a partir de', 'woocommerce' ),
            'type' => 'select',
            'description' => __( 'A cobrança de taxa inicia em, total cobrado será valor do pedido + taxa ', 'woocommerce' ),
            'desc_tip' => false,
            'default' => '0',
            'class' => 'wc-enhanced-select',
            'options' => array(
                '0'  => __( 'Todas as parcelas', 'woocommerce' ),
                '1'  => __( '1x', 'woocommerce' ),
                '2'  => __( '2x', 'woocommerce' ),
                '3'  => __( '3x', 'woocommerce' ),
                '4'  => __( '4x', 'woocommerce' ),
                '5'  => __( '5x', 'woocommerce' ),
                '6'  => __( '6x', 'woocommerce' ),
                '7'  => __( '7x', 'woocommerce' ),
                '8'  => __( '8x', 'woocommerce' ),
                '9'  => __( '9x', 'woocommerce' ),
                '10' => __( '10x', 'woocommerce' ),
                '11' => __( '11x', 'woocommerce' ),
                '12' => __( '12x', 'woocommerce' )
            )
        ),
        'tax_1' => array(
            'title' => __( 'Taxa de juros em 1x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 4.20 = 4,2%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '4.20',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_2' => array(
            'title' => __( 'Taxa de juros em 2x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 5.60 = 5,6%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '5.60',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_3' => array(
            'title' => __( 'Taxa de juros em 3x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 6.89 = 6,89%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '6.89',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_4' => array(
            'title' => __( 'Taxa de juros em 4x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 7.31 = 7,31%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '7.31',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_5' => array(
            'title' => __( 'Taxa de juros em 5x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 8.10 = 8,1%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '8.10',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_6' => array(
            'title' => __( 'Taxa de juros em 6x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 9.60 = 9,6%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '9.60',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_7' => array(
            'title' => __( 'Taxa de juros em 7x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 12.33 = 12,33%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '12.33',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_8' => array(
            'title' => __( 'Taxa de juros em 8x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 12.90 = 12,9%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '12.90',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_9' => array(
            'title' => __( 'Taxa de juros em 9x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 13.35 = 13,35%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '13.35',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_10' => array(
            'title' => __( 'Taxa de juros em 10x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 13.80 = 13,8%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '13.80',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_11' => array(
            'title' => __( 'Taxa de juros em 11x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 14.10 = 14,1%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '14.10',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'tax_12' => array(
            'title' => __( 'Taxa de juros em 12x', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Exemplo 14.40 = 14,4%', 'woocommerce' ),
            'class' => 'aqpago-display-none aqpago-tax',
            'default' => '14.40',
            'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
        ),
        'debug' => array(
            'title'       => __( 'Gravar Log', 'woocommerce' ),
            'type'        => 'checkbox',
            'label'       => __( 'Ativar log', 'woocommerce' ),
            'default'     => 'no',
            'description' => sprintf( __( 'Gravar log das transações, desativar ao finalizar os testes.', 'woocommerce' ) ),
        )
    );
}