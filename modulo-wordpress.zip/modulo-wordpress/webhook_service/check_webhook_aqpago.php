<?php



use GuzzleHttp\Client;

class CheckWebhookAqPago {
    private $apiUrl;
    private $token;
    private $client;

    public function __construct($apiUrl, $token) {
        $this->apiUrl = $apiUrl;
        $this->token = $token;
        $this->client = new Client(['base_uri' => $this->apiUrl]);
        
    }
    public function getWebhook() {
        $response = $this->client->request('GET', '', [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->token,
                'Accept'        => 'application/json',
            ],
        ]);

        return json_decode($response->getBody(), true);
    }
    public function ensureWebhookExists($webhookModel) {
        $response = $this->getWebhook();
    
        print_r($response, true);
    
        if (is_array($response)) {
            echo print_r($response, true);
            $response = json_encode($response);            
        }
        else{
            echo $response;
        }
    
        $data = json_decode($response, true);
    
        $webhookExists = false;
        $url = $webhookModel->getUrl();
    
        foreach ($data['webhooks'] as $item) {
            if (isset($item['url']) && $item['url'] === $url) {
                $webhookExists = true;
                echo 'ja tem webhook cadastrado';
                break;
            }
        }
    
        if (!$webhookExists) {
            echo 'webhook não existe, cadastando';
            $this->createWebhook($webhookModel);
        }
    }
    public function createWebhook($webhookModel) {
        $data = [
            'event' => $webhookModel->getEvent(),
            'url' =>  $webhookModel->getUrl(),
            'description' => $webhookModel->getDescription(),
            'method' => $webhookModel->getMethod()
        ];
    
        $response = $this->client->request('POST', '', [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->token,
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
            ],
            'json' => $data,
        ]);
    
        return json_decode($response->getBody(), true);
    }
    

}

