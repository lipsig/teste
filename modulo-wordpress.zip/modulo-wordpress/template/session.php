<script>
window.onload = (function(){        
    AQPAGOSECTION.setPublicToken("{$fingerprint}");        
});
</script>