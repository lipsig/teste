<?php

class Webhook {
    private $event;
    private $url;
    private $description;
    private $method;

    public function setEvent($event) {
        $this->event = $event;
    }

    public function getEvent() {
        return $this->event;
    }

    public function setUrl($url) {
        $this->url = $url;
    }

    public function getUrl() {
        return $this->url;
    }

    public function setDescription($description) {
        $this->description = $description;
    }

    public function getDescription() {
        return $this->description;
    }

    public function setMethod($method) {
        $this->method = $method;
    }

    public function getMethod() {
        return $this->method;
    }
}