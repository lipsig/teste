<?php

namespace Customer;

class Customer{
    public function __construct(
        private $costumer_name,
        private $costumer_last_name,
        private $costumer_email,
        private $costumer_phones,
        private $costumer_address,
        private $costumer_document,
        private $costumer_type, 
    ){}    
    public function getCostumerName(){
        return $this->costumer_name;
    }
    public function setCostumerName($costumer_name){
        $this->costumer_name = $costumer_name;
    }
    public function getCostumerLastName(){
        return $this->costumer_last_name;
    }
    public function setCostumerLastName($costumer_last_name){
        $this->costumer_last_name = $costumer_last_name;
    }
    public function getCostumerEmail(){
        return $this->costumer_email;
    }
    public function setCostumerEmail($costumer_email){
        $this->costumer_email = $costumer_email;
    }
    public function getCostumerPhones(){
        return $this->costumer_phones;
    }
    public function setCostumerPhones($costumer_phones){
        $this->costumer_phones = $costumer_phones;
    }
    public function getCostumerAddress(){
        return $this->costumer_address;
    }
    public function setCostumerAddress($costumer_address){
        $this->costumer_address = $costumer_address;
    }
    public function getCostumerDocument(){
        return $this->costumer_document;
    }
    public function setCostumerDocument($costumer_document){
        $this->costumer_document = $costumer_document;
    }
    public function getCostumer_type(){
        return $this->costumer_type;
    }
    public function setCostumer_type($costumer_type){
        $this->costumer_type = $costumer_type;
    }
}


