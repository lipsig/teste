<?php

namespace Authmiddleware\Authenticate;
namespace Order;

class Order{  
        
    public function __construct(
        private $order_id,
        private $session_id,
        private $reference_id,
        private $amount,
        private $type,
        private $description,
        private $costumer,
        private $shipping,
        private $items,
        private $payments,
        private $success,
        private $error,
        private $message
    ){}  
    
    public function getOrderId(){
        return $this->order_id;
    }
    public function setOrderId($order_id){
        $this->order_id = $order_id;
    }
    public function getSessionId(){
        return $this->session_id;
    }
    public function setSessionId($session_id){
        $this->session_id = $session_id;
    }
    public function getReferenceId(){
        return $this->reference_id;
    }
    public function setReferenceId($reference_id){
        $this->reference_id = $reference_id;
    }
    public function getAmount(){
        return $this->amount;
    }
    public function setAmount($amount){
        $this->amount = $amount;
    }
    public function getType(){
        return $this->type;
    }
    public function setType($type){
        $this->type = $type;
    }
    public function getDescription(){
        return $this->description;
    }
    public function setDescription($description){
        $this->description = $description;
    }
    public function getCostumer(){
        return $this->costumer;
    }
    public function setCostumer($costumer){
        $this->costumer = $costumer;
    }
    public function getShipping(){
        return $this->shipping;
    }
    public function setShipping($shipping){
        $this->shipping = $shipping;
    }
    public function getItems(){
        return $this->items;
    }
    public function setItems($items){
        $this->items = $items;
    }
    public function getPayments(){
        return $this->payments;
    }
    public function setPayments($payments){
        $this->payments = $payments;
    }
    public function getSuccess(){
        return $this->success;
    }
    public function setSuccess($success){
        $this->success = $success;
    }
    public function getError(){
        return $this->error;
    }
    public function setError($error){
        $this->error = $error;
    }
    public function getMessage(){
        return $this->message;
    }
    public function setMessage($message){
        $this->message = $message;
    }   
}





