

(
    [id:protected] => 234
    [data:protected] => Array
        (
            [parent_id] => 0
            [status] => pending
            [currency] => USD
            [version] => 8.7.0
            [prices_include_tax] => 
            [date_created] => WC_DateTime Object
                (
                    [utc_offset:protected] => 0
                    [date] => 2024-04-11 11:07:08.000000
                    [timezone_type] => 3
                    [timezone] => America/Sao_Paulo
                )

            [date_modified] => WC_DateTime Object
                (
                    [utc_offset:protected] => 0
                    [date] => 2024-04-11 11:07:08.000000
                    [timezone_type] => 3
                    [timezone] => America/Sao_Paulo
                )

            [discount_total] => 0
            [discount_tax] => 0
            [shipping_total] => 0
            [shipping_tax] => 0
            [cart_tax] => 0
            [total] => 1.00
            [total_tax] => 0
            [customer_id] => 1
            [order_key] => wc_order_p7uhFc2XT7875
            [billing] => Array
                (
                    [first_name] => teste
                    [last_name] => teste
                    [company] => teste
                    [address_1] => rua teste
                    [address_2] => 12323
                    [city] => tete
                    [state] => BA
                    [postcode] => 02150-000
                    [country] => BR
                    [email] => luis.lourezi@aqbank.com.br
                    [phone] => (11) 3549-393
                )

            [shipping] => Array
                (
                    [first_name] => 
                    [last_name] => 
                    [company] => 
                    [address_1] => 
                    [address_2] => 
                    [city] => 
                    [state] => 
                    [postcode] => 
                    [country] => 
                    [phone] => 
                )

            [payment_method] => aqpago
            [payment_method_title] => AqBank Gateway
            [transaction_id] => 
            [customer_ip_address] => ::1
            [customer_user_agent] => Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36
            [created_via] => checkout
            [customer_note] => 
            [date_completed] => 
            [date_paid] => 
            [cart_hash] => c3793863c8d42cea5bd63e68478c68ae
            [order_stock_reduced] => 
            [download_permissions_granted] => 
            [new_order_email_sent] => 
            [recorded_sales] => 
            [recorded_coupon_usage_counts] => 
        )

    [changes:protected] => Array
        (
        )

    [object_read:protected] => 1
    [object_type:protected] => order
    [extra_data:protected] => Array
        (
        )

    [default_data:protected] => Array
        (
            [parent_id] => 0
            [status] => 
            [currency] => 
            [version] => 
            [prices_include_tax] => 
            [date_created] => 
            [date_modified] => 
            [discount_total] => 0
            [discount_tax] => 0
            [shipping_total] => 0
            [shipping_tax] => 0
            [cart_tax] => 0
            [total] => 0
            [total_tax] => 0
            [customer_id] => 0
            [order_key] => 
            [billing] => Array
                (
                    [first_name] => 
                    [last_name] => 
                    [company] => 
                    [address_1] => 
                    [address_2] => 
                    [city] => 
                    [state] => 
                    [postcode] => 
                    [country] => 
                    [email] => 
                    [phone] => 
                )

            [shipping] => Array
                (
                    [first_name] => 
                    [last_name] => 
                    [company] => 
                    [address_1] => 
                    [address_2] => 
                    [city] => 
                    [state] => 
                    [postcode] => 
                    [country] => 
                    [phone] => 
                )

            [payment_method] => 
            [payment_method_title] => 
            [transaction_id] => 
            [customer_ip_address] => 
            [customer_user_agent] => 
            [created_via] => 
            [customer_note] => 
            [date_completed] => 
            [date_paid] => 
            [cart_hash] => 
            [order_stock_reduced] => 
            [download_permissions_granted] => 
            [new_order_email_sent] => 
            [recorded_sales] => 
            [recorded_coupon_usage_counts] => 
        )

    [data_store:protected] => WC_Data_Store Object
        (
            [instance:WC_Data_Store:private] => Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStore Object
                (
                    [meta_type:protected] => post
                    [object_id_field_for_meta:protected] => 
                    [internal_meta_keys:protected] => Array
                        (
                            [0] => _parent_id
                            [1] => _status
                            [2] => _currency
                            [3] => _version
                            [4] => _prices_include_tax
                            [5] => _date_created
                            [6] => _date_modified
                            [7] => _discount_total
                            [8] => _discount_tax
                            [9] => _shipping_total
                            [10] => _shipping_tax
                            [11] => _cart_tax
                            [12] => _total
                            [13] => _total_tax
                            [14] => _customer_id
                            [15] => _order_key
                            [16] => _billing
                            [17] => _shipping
                            [18] => _payment_method
                            [19] => _payment_method_title
                            [20] => _transaction_id
                            [21] => _customer_ip_address
                            [22] => _customer_user_agent
                            [23] => _created_via
                            [24] => _customer_note
                            [25] => _date_completed
                            [26] => _date_paid
                            [27] => _cart_hash
                            [28] => _order_stock_reduced
                            [29] => _download_permissions_granted
                            [30] => _new_order_email_sent
                            [31] => _recorded_sales
                            [32] => _recorded_coupon_usage_counts
                            [66] => _customer_user
                            [67] => _order_currency
                            [68] => _billing_first_name
                            [69] => _billing_last_name
                            [70] => _billing_company
                            [71] => _billing_address_1
                            [72] => _billing_address_2
                            [73] => _billing_city
                            [74] => _billing_state
                            [75] => _billing_postcode
                            [76] => _billing_country
                            [77] => _billing_email
                            [78] => _billing_phone
                            [79] => _shipping_first_name
                            [80] => _shipping_last_name
                            [81] => _shipping_company
                            [82] => _shipping_address_1
                            [83] => _shipping_address_2
                            [84] => _shipping_city
                            [85] => _shipping_state
                            [86] => _shipping_postcode
                            [87] => _shipping_country
                            [88] => _shipping_phone
                            [89] => _completed_date
                            [90] => _paid_date
                            [91] => _edit_last
                            [92] => _cart_discount
                            [93] => _cart_discount_tax
                            [94] => _order_shipping
                            [95] => _order_shipping_tax
                            [96] => _order_tax
                            [97] => _order_total
                            [98] => _order_version
                            [99] => _payment_tokens
                            [100] => _billing_address_index
                            [101] => _shipping_address_index
                        )

                    [must_exist_meta_keys:protected] => Array
                        (
                        )

                    [internal_data_store_key_getters:protected] => Array
                        (
                        )

                    [ephemeral_meta_keys:protected] => Array
                        (
                            [0] => _edit_lock
                        )

                    [data_store_meta:protected] => Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStoreMeta Object
                        (
                        )

                    [database_util:protected] => Automattic\WooCommerce\Internal\Utilities\DatabaseUtil Object
                        (
                        )

                    [cpt_data_store:Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStore:private] => 
                    [error_logger:Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStore:private] => WC_Logger Object
                        (
                            [handlers:protected] => Array
                                (
                                    [0] => Automattic\WooCommerce\Internal\Admin\Logging\LogHandlerFileV2 Object
                                        (
                                            [file_controller:Automattic\WooCommerce\Internal\Admin\Logging\LogHandlerFileV2:private] => Automattic\WooCommerce\Internal\Admin\Logging\FileV2\FileController Object
                                                (
                                                    [log_directory:Automattic\WooCommerce\Internal\Admin\Logging\FileV2\FileController:private] => C:\laragon\www\wordpress/wp-content/uploads/wc-logs/
                                                )

                                            [settings:Automattic\WooCommerce\Internal\Admin\Logging\LogHandlerFileV2:private] => Automattic\WooCommerce\Internal\Admin\Logging\Settings Object
                                                (
                                                    [_accessible_private_methods:Automattic\WooCommerce\Internal\Admin\Logging\Settings:private] => Array
                                                        (
                                                            [save_settings] => save_settings
                                                        )

                                                )

                                        )

                                )

                            [threshold:protected] => 0
                        )

                    [orders_table_name:Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStore:private] => wp_wc_orders
                    [legacy_proxy:Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStore:private] => Automattic\WooCommerce\Proxies\LegacyProxy Object
                        (
                        )

                    [order_column_mapping:protected] => Array
                        (
                            [id] => Array
                                (
                                    [type] => int
                                    [name] => id
                                )

                            [status] => Array
                                (
                                    [type] => string
                                    [name] => status
                                )

                            [type] => Array
                                (
                                    [type] => string
                                    [name] => type
                                )

                            [currency] => Array
                                (
                                    [type] => string
                                    [name] => currency
                                )

                            [tax_amount] => Array
                                (
                                    [type] => decimal
                                    [name] => cart_tax
                                )

                            [total_amount] => Array
                                (
                                    [type] => decimal
                                    [name] => total
                                )

                            [customer_id] => Array
                                (
                                    [type] => int
                                    [name] => customer_id
                                )

                            [billing_email] => Array
                                (
                                    [type] => string
                                    [name] => billing_email
                                )

                            [date_created_gmt] => Array
                                (
                                    [type] => date
                                    [name] => date_created
                                )

                            [date_updated_gmt] => Array
                                (
                                    [type] => date
                                    [name] => date_modified
                                )

                            [parent_order_id] => Array
                                (
                                    [type] => int
                                    [name] => parent_id
                                )

                            [payment_method] => Array
                                (
                                    [type] => string
                                    [name] => payment_method
                                )

                            [payment_method_title] => Array
                                (
                                    [type] => string
                                    [name] => payment_method_title
                                )

                            [ip_address] => Array
                                (
                                    [type] => string
                                    [name] => customer_ip_address
                                )

                            [transaction_id] => Array
                                (
                                    [type] => string
                                    [name] => transaction_id
                                )

                            [user_agent] => Array
                                (
                                    [type] => string
                                    [name] => customer_user_agent
                                )

                            [customer_note] => Array
                                (
                                    [type] => string
                                    [name] => customer_note
                                )

                        )

                    [billing_address_column_mapping:protected] => Array
                        (
                            [id] => Array
                                (
                                    [type] => int
                                )

                            [order_id] => Array
                                (
                                    [type] => int
                                )

                            [address_type] => Array
                                (
                                    [type] => string
                                )

                            [first_name] => Array
                                (
                                    [type] => string
                                    [name] => billing_first_name
                                )

                            [last_name] => Array
                                (
                                    [type] => string
                                    [name] => billing_last_name
                                )

                            [company] => Array
                                (
                                    [type] => string
                                    [name] => billing_company
                                )

                            [address_1] => Array
                                (
                                    [type] => string
                                    [name] => billing_address_1
                                )

                            [address_2] => Array
                                (
                                    [type] => string
                                    [name] => billing_address_2
                                )

                            [city] => Array
                                (
                                    [type] => string
                                    [name] => billing_city
                                )

                            [state] => Array
                                (
                                    [type] => string
                                    [name] => billing_state
                                )

                            [postcode] => Array
                                (
                                    [type] => string
                                    [name] => billing_postcode
                                )

                            [country] => Array
                                (
                                    [type] => string
                                    [name] => billing_country
                                )

                            [email] => Array
                                (
                                    [type] => string
                                    [name] => billing_email
                                )

                            [phone] => Array
                                (
                                    [type] => string
                                    [name] => billing_phone
                                )

                        )

                    [shipping_address_column_mapping:protected] => Array
                        (
                            [id] => Array
                                (
                                    [type] => int
                                )

                            [order_id] => Array
                                (
                                    [type] => int
                                )

                            [address_type] => Array
                                (
                                    [type] => string
                                )

                            [first_name] => Array
                                (
                                    [type] => string
                                    [name] => shipping_first_name
                                )

                            [last_name] => Array
                                (
                                    [type] => string
                                    [name] => shipping_last_name
                                )

                            [company] => Array
                                (
                                    [type] => string
                                    [name] => shipping_company
                                )

                            [address_1] => Array
                                (
                                    [type] => string
                                    [name] => shipping_address_1
                                )

                            [address_2] => Array
                                (
                                    [type] => string
                                    [name] => shipping_address_2
                                )

                            [city] => Array
                                (
                                    [type] => string
                                    [name] => shipping_city
                                )

                            [state] => Array
                                (
                                    [type] => string
                                    [name] => shipping_state
                                )

                            [postcode] => Array
                                (
                                    [type] => string
                                    [name] => shipping_postcode
                                )

                            [country] => Array
                                (
                                    [type] => string
                                    [name] => shipping_country
                                )

                            [email] => Array
                                (
                                    [type] => string
                                )

                            [phone] => Array
                                (
                                    [type] => string
                                    [name] => shipping_phone
                                )

                        )

                    [operational_data_column_mapping:protected] => Array
                        (
                            [id] => Array
                                (
                                    [type] => int
                                )

                            [order_id] => Array
                                (
                                    [type] => int
                                )

                            [created_via] => Array
                                (
                                    [type] => string
                                    [name] => created_via
                                )

                            [woocommerce_version] => Array
                                (
                                    [type] => string
                                    [name] => version
                                )

                            [prices_include_tax] => Array
                                (
                                    [type] => bool
                                    [name] => prices_include_tax
                                )

                            [coupon_usages_are_counted] => Array
                                (
                                    [type] => bool
                                    [name] => recorded_coupon_usage_counts
                                )

                            [download_permission_granted] => Array
                                (
                                    [type] => bool
                                    [name] => download_permissions_granted
                                )

                            [cart_hash] => Array
                                (
                                    [type] => string
                                    [name] => cart_hash
                                )

                            [new_order_email_sent] => Array
                                (
                                    [type] => bool
                                    [name] => new_order_email_sent
                                )

                            [order_key] => Array
                                (
                                    [type] => string
                                    [name] => order_key
                                )

                            [order_stock_reduced] => Array
                                (
                                    [type] => bool
                                    [name] => order_stock_reduced
                                )

                            [date_paid_gmt] => Array
                                (
                                    [type] => date
                                    [name] => date_paid
                                )

                            [date_completed_gmt] => Array
                                (
                                    [type] => date
                                    [name] => date_completed
                                )

                            [shipping_tax_amount] => Array
                                (
                                    [type] => decimal
                                    [name] => shipping_tax
                                )

                            [shipping_total_amount] => Array
                                (
                                    [type] => decimal
                                    [name] => shipping_total
                                )

                            [discount_tax_amount] => Array
                                (
                                    [type] => decimal
                                    [name] => discount_tax
                                )

                            [discount_total_amount] => Array
                                (
                                    [type] => decimal
                                    [name] => discount_total
                                )

                            [recorded_sales] => Array
                                (
                                    [type] => bool
                                    [name] => recorded_sales
                                )

                        )

                    [all_order_column_mapping:Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStore:private] => Array
                        (
                            [orders] => Array
                                (
                                    [id] => Array
                                        (
                                            [type] => int
                                            [name] => id
                                        )

                                    [status] => Array
                                        (
                                            [type] => string
                                            [name] => status
                                        )

                                    [type] => Array
                                        (
                                            [type] => string
                                            [name] => type
                                        )

                                    [currency] => Array
                                        (
                                            [type] => string
                                            [name] => currency
                                        )

                                    [tax_amount] => Array
                                        (
                                            [type] => decimal
                                            [name] => cart_tax
                                        )

                                    [total_amount] => Array
                                        (
                                            [type] => decimal
                                            [name] => total
                                        )

                                    [customer_id] => Array
                                        (
                                            [type] => int
                                            [name] => customer_id
                                        )

                                    [billing_email] => Array
                                        (
                                            [type] => string
                                            [name] => billing_email
                                        )

                                    [date_created_gmt] => Array
                                        (
                                            [type] => date
                                            [name] => date_created
                                        )

                                    [date_updated_gmt] => Array
                                        (
                                            [type] => date
                                            [name] => date_modified
                                        )

                                    [parent_order_id] => Array
                                        (
                                            [type] => int
                                            [name] => parent_id
                                        )

                                    [payment_method] => Array
                                        (
                                            [type] => string
                                            [name] => payment_method
                                        )

                                    [payment_method_title] => Array
                                        (
                                            [type] => string
                                            [name] => payment_method_title
                                        )

                                    [ip_address] => Array
                                        (
                                            [type] => string
                                            [name] => customer_ip_address
                                        )

                                    [transaction_id] => Array
                                        (
                                            [type] => string
                                            [name] => transaction_id
                                        )

                                    [user_agent] => Array
                                        (
                                            [type] => string
                                            [name] => customer_user_agent
                                        )

                                    [customer_note] => Array
                                        (
                                            [type] => string
                                            [name] => customer_note
                                        )

                                )

                            [billing_address] => Array
                                (
                                    [id] => Array
                                        (
                                            [type] => int
                                        )

                                    [order_id] => Array
                                        (
                                            [type] => int
                                        )

                                    [address_type] => Array
                                        (
                                            [type] => string
                                        )

                                    [first_name] => Array
                                        (
                                            [type] => string
                                            [name] => billing_first_name
                                        )

                                    [last_name] => Array
                                        (
                                            [type] => string
                                            [name] => billing_last_name
                                        )

                                    [company] => Array
                                        (
                                            [type] => string
                                            [name] => billing_company
                                        )

                                    [address_1] => Array
                                        (
                                            [type] => string
                                            [name] => billing_address_1
                                        )

                                    [address_2] => Array
                                        (
                                            [type] => string
                                            [name] => billing_address_2
                                        )

                                    [city] => Array
                                        (
                                            [type] => string
                                            [name] => billing_city
                                        )

                                    [state] => Array
                                        (
                                            [type] => string
                                            [name] => billing_state
                                        )

                                    [postcode] => Array
                                        (
                                            [type] => string
                                            [name] => billing_postcode
                                        )

                                    [country] => Array
                                        (
                                            [type] => string
                                            [name] => billing_country
                                        )

                                    [email] => Array
                                        (
                                            [type] => string
                                            [name] => billing_email
                                        )

                                    [phone] => Array
                                        (
                                            [type] => string
                                            [name] => billing_phone
                                        )

                                )

                            [shipping_address] => Array
                                (
                                    [id] => Array
                                        (
                                            [type] => int
                                        )

                                    [order_id] => Array
                                        (
                                            [type] => int
                                        )

                                    [address_type] => Array
                                        (
                                            [type] => string
                                        )

                                    [first_name] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_first_name
                                        )

                                    [last_name] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_last_name
                                        )

                                    [company] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_company
                                        )

                                    [address_1] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_address_1
                                        )

                                    [address_2] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_address_2
                                        )

                                    [city] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_city
                                        )

                                    [state] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_state
                                        )

                                    [postcode] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_postcode
                                        )

                                    [country] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_country
                                        )

                                    [email] => Array
                                        (
                                            [type] => string
                                        )

                                    [phone] => Array
                                        (
                                            [type] => string
                                            [name] => shipping_phone
                                        )

                                )

                            [operational_data] => Array
                                (
                                    [id] => Array
                                        (
                                            [type] => int
                                        )

                                    [order_id] => Array
                                        (
                                            [type] => int
                                        )

                                    [created_via] => Array
                                        (
                                            [type] => string
                                            [name] => created_via
                                        )

                                    [woocommerce_version] => Array
                                        (
                                            [type] => string
                                            [name] => version
                                        )

                                    [prices_include_tax] => Array
                                        (
                                            [type] => bool
                                            [name] => prices_include_tax
                                        )

                                    [coupon_usages_are_counted] => Array
                                        (
                                            [type] => bool
                                            [name] => recorded_coupon_usage_counts
                                        )

                                    [download_permission_granted] => Array
                                        (
                                            [type] => bool
                                            [name] => download_permissions_granted
                                        )

                                    [cart_hash] => Array
                                        (
                                            [type] => string
                                            [name] => cart_hash
                                        )

                                    [new_order_email_sent] => Array
                                        (
                                            [type] => bool
                                            [name] => new_order_email_sent
                                        )

                                    [order_key] => Array
                                        (
                                            [type] => string
                                            [name] => order_key
                                        )

                                    [order_stock_reduced] => Array
                                        (
                                            [type] => bool
                                            [name] => order_stock_reduced
                                        )

                                    [date_paid_gmt] => Array
                                        (
                                            [type] => date
                                            [name] => date_paid
                                        )

                                    [date_completed_gmt] => Array
                                        (
                                            [type] => date
                                            [name] => date_completed
                                        )

                                    [shipping_tax_amount] => Array
                                        (
                                            [type] => decimal
                                            [name] => shipping_tax
                                        )

                                    [shipping_total_amount] => Array
                                        (
                                            [type] => decimal
                                            [name] => shipping_total
                                        )

                                    [discount_tax_amount] => Array
                                        (
                                            [type] => decimal
                                            [name] => discount_tax
                                        )

                                    [discount_total_amount] => Array
                                        (
                                            [type] => decimal
                                            [name] => discount_total
                                        )

                                    [recorded_sales] => Array
                                        (
                                            [type] => bool
                                            [name] => recorded_sales
                                        )

                                )

                        )

                )

            [stores:WC_Data_Store:private] => Array
                (
                    [coupon] => WC_Coupon_Data_Store_CPT
                    [customer] => WC_Customer_Data_Store
                    [customer-download] => WC_Customer_Download_Data_Store
                    [customer-download-log] => WC_Customer_Download_Log_Data_Store
                    [customer-session] => WC_Customer_Data_Store_Session
                    [order] => WC_Order_Data_Store_CPT
                    [order-refund] => WC_Order_Refund_Data_Store_CPT
                    [order-item] => WC_Order_Item_Data_Store
                    [order-item-coupon] => WC_Order_Item_Coupon_Data_Store
                    [order-item-fee] => WC_Order_Item_Fee_Data_Store
                    [order-item-product] => WC_Order_Item_Product_Data_Store
                    [order-item-shipping] => WC_Order_Item_Shipping_Data_Store
                    [order-item-tax] => WC_Order_Item_Tax_Data_Store
                    [payment-token] => WC_Payment_Token_Data_Store
                    [product] => WC_Product_Data_Store_CPT
                    [product-grouped] => WC_Product_Grouped_Data_Store_CPT
                    [product-variable] => WC_Product_Variable_Data_Store_CPT
                    [product-variation] => WC_Product_Variation_Data_Store_CPT
                    [shipping-zone] => WC_Shipping_Zone_Data_Store
                    [webhook] => WC_Webhook_Data_Store
                    [report-revenue-stats] => Automattic\WooCommerce\Admin\API\Reports\Orders\Stats\DataStore
                    [report-orders] => Automattic\WooCommerce\Admin\API\Reports\Orders\DataStore
                    [report-orders-stats] => Automattic\WooCommerce\Admin\API\Reports\Orders\Stats\DataStore
                    [report-products] => Automattic\WooCommerce\Admin\API\Reports\Products\DataStore
                    [report-variations] => Automattic\WooCommerce\Admin\API\Reports\Variations\DataStore
                    [report-products-stats] => Automattic\WooCommerce\Admin\API\Reports\Products\Stats\DataStore
                    [report-variations-stats] => Automattic\WooCommerce\Admin\API\Reports\Variations\Stats\DataStore
                    [report-categories] => Automattic\WooCommerce\Admin\API\Reports\Categories\DataStore
                    [report-taxes] => Automattic\WooCommerce\Admin\API\Reports\Taxes\DataStore
                    [report-taxes-stats] => Automattic\WooCommerce\Admin\API\Reports\Taxes\Stats\DataStore
                    [report-coupons] => Automattic\WooCommerce\Admin\API\Reports\Coupons\DataStore
                    [report-coupons-stats] => Automattic\WooCommerce\Admin\API\Reports\Coupons\Stats\DataStore
                    [report-downloads] => Automattic\WooCommerce\Admin\API\Reports\Downloads\DataStore
                    [report-downloads-stats] => Automattic\WooCommerce\Admin\API\Reports\Downloads\Stats\DataStore
                    [admin-note] => Automattic\WooCommerce\Admin\Notes\DataStore
                    [report-customers] => Automattic\WooCommerce\Admin\API\Reports\Customers\DataStore
                    [report-customers-stats] => Automattic\WooCommerce\Admin\API\Reports\Customers\Stats\DataStore
                    [report-stock-stats] => Automattic\WooCommerce\Admin\API\Reports\Stock\Stats\DataStore
                )

            [current_class_name:WC_Data_Store:private] => Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStore
            [object_type:WC_Data_Store:private] => order
        )

    [cache_group:protected] => orders
    [meta_data:protected] => Array
        (
            [0] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2501
                            [key] => _billing_address_index
                            [value] => teste teste teste rua teste 12323 tete BA 02150-000 BR luis.lourezi@aqbank.com.br (11) 3549-393
                        )

                    [data:protected] => Array
                        (
                            [id] => 2501
                            [key] => _billing_address_index
                            [value] => teste teste teste rua teste 12323 tete BA 02150-000 BR luis.lourezi@aqbank.com.br (11) 3549-393
                        )

                )

            [1] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2502
                            [key] => _shipping_address_index
                            [value] =>          
                        )

                    [data:protected] => Array
                        (
                            [id] => 2502
                            [key] => _shipping_address_index
                            [value] =>          
                        )

                )

            [2] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2510
                            [key] => _wc_order_attribution_device_type
                            [value] => Desktop
                        )

                    [data:protected] => Array
                        (
                            [id] => 2510
                            [key] => _wc_order_attribution_device_type
                            [value] => Desktop
                        )

                )

            [3] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2508
                            [key] => _wc_order_attribution_session_count
                            [value] => 1
                        )

                    [data:protected] => Array
                        (
                            [id] => 2508
                            [key] => _wc_order_attribution_session_count
                            [value] => 1
                        )

                )

            [4] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2505
                            [key] => _wc_order_attribution_session_entry
                            [value] => http://localhost/wordpress/carrinho/
                        )

                    [data:protected] => Array
                        (
                            [id] => 2505
                            [key] => _wc_order_attribution_session_entry
                            [value] => http://localhost/wordpress/carrinho/
                        )

                )

            [5] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2507
                            [key] => _wc_order_attribution_session_pages
                            [value] => 58
                        )

                    [data:protected] => Array
                        (
                            [id] => 2507
                            [key] => _wc_order_attribution_session_pages
                            [value] => 58
                        )

                )

            [6] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2506
                            [key] => _wc_order_attribution_session_start_time
                            [value] => 2024-04-11 11:31:13
                        )

                    [data:protected] => Array
                        (
                            [id] => 2506
                            [key] => _wc_order_attribution_session_start_time
                            [value] => 2024-04-11 11:31:13
                        )

                )

            [7] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2503
                            [key] => _wc_order_attribution_source_type
                            [value] => typein
                        )

                    [data:protected] => Array
                        (
                            [id] => 2503
                            [key] => _wc_order_attribution_source_type
                            [value] => typein
                        )

                )

            [8] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2509
                            [key] => _wc_order_attribution_user_agent
                            [value] => Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36
                        )

                    [data:protected] => Array
                        (
                            [id] => 2509
                            [key] => _wc_order_attribution_user_agent
                            [value] => Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36
                        )

                )

            [9] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2504
                            [key] => _wc_order_attribution_utm_source
                            [value] => (direct)
                        )

                    [data:protected] => Array
                        (
                            [id] => 2504
                            [key] => _wc_order_attribution_utm_source
                            [value] => (direct)
                        )

                )

            [10] => WC_Meta_Data Object
                (
                    [current_data:protected] => Array
                        (
                            [id] => 2500
                            [key] => is_vat_exempt
                            [value] => no
                        )

                    [data:protected] => Array
                        (
                            [id] => 2500
                            [key] => is_vat_exempt
                            [value] => no
                        )

                )

        )

    [legacy_datastore_props:protected] => Array
        (
            [0] => _recorded_sales
            [1] => _recorded_coupon_usage_counts
            [2] => _download_permissions_granted
            [3] => _order_stock_reduced
            [4] => _new_order_email_sent
        )

    [items:protected] => Array
        (
        )

    [items_to_delete:protected] => Array
        (
        )

    [data_store_name:protected] => order
    [status_transition:protected] => 
    [refunds] => 
    [refunded_line_items:protected] => 
    [customer_id] => 
)